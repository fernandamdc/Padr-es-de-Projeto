public class Principal {
    public static void main(String[] args) {
        LeituraRetorno leituraRetorno = new LeituraRetornoBancoBrasil();
        ProcessarBoletos processador = new ProcessarBoletos(leituraRetorno);
        //processador.setLeituraRetorno(leituraRetorno);
        processador.processar("banco-brasil-1.csv");

        leituraRetorno = new LeituraRetornoBradesco();
        processador = new ProcessarBoletos(leituraRetorno);
        processador.processar("bradesco-1.csv");
    }
}
