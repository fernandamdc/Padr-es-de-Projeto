public class ProcessarBoletos {
    private LeituraRetorno leituraRetorno;

    public ProcessarBoletos(LeituraRetorno leituraRetorno) {

        this.leituraRetorno = leituraRetorno;
    }

    public void processar (String nomeArquivo){
        var lista = leituraRetorno.lerArquivo(nomeArquivo);
        for (Boleto boleto : lista) {
            System.out.println(boleto);
        }
    }

    public void setLeituraRetorno(LeituraRetorno leituraRetorno) {
        this.leituraRetorno = leituraRetorno;
    }
}
